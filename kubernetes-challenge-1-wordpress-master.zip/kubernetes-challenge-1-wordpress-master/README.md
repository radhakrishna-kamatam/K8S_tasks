# Kubernetes Challenge - 1 - Wordpress

This is a solution to the Kubernetes Challenge series hosted at KodeKloud

Access the hands-on challenge here:

https://kodekloud.com/p/practice-test-kubernetes-challenge-1-wordpress

![alt text](wordpress-challenge.png)